package pkg_1_Basics;

public class Session5_1Arrays1
{
	public static void main(String[] args)
	{
		/*
		 * Exercise with int arrays
		 */

		/* List all members of the Array */

		int[] myArray = {1,108,33,93,14,35,16,3,26,67,98,49,108,5,2,0,55,88,53,125,14,102,67,88,44,4,3,100};
		//int length =myArray.
		
		int[] dupArray = myArray.clone();
		int length2 = dupArray.length;
		System.out.println("Length2 = "+length2);
		
		int length = myArray.length;
		
		//boolean flag = false;
			
		/* List all members of the Array */
		System.out.println("myArray Length: " + length);
		System.out.println("myArray[] Contents:");
		int sum = 0;
		
		for (int i = 0; i < length; i++)
		{	
			sum = sum + myArray[i];
		}
			//System.out.println("myArray[" + i + "]" + "= " + myArray[i]);
			System.out.println("SUM = " +sum);
			
		int min = myArray[0];
		int max = myArray[0];
		
		//min
		for (int i = 1; i < length; i++)
		{
			if (myArray[i] < min)
				min = myArray[i];
			
		}
		System.out.println("Min = "+min);
		
		//max
		for (int i = 1; i < length; i++)
		{
			if (myArray[i] > max)
				max = myArray[i];
			
		}
		System.out.println("Max = "+max);
		
	}

}
