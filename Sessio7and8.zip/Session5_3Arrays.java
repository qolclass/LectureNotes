package pkg_1_Basics;

public class Session5_3Arrays {

	public static void main(String[] args) 
	{
		/*
		 * Syntax: datatype arrayname[] = new datatype[size];
		 */
		
		//Single dimension arrays
		int student_id[] = new int[4];
		//int[] student_id2 = new int[4];
		
		student_id[0] = 50;
		student_id[1] = 60;
		student_id[2] = 70;
		student_id[3] = 80;
		//student_id[4] = 100;
		
		
		System.out.println("\nThe score for all students are as follows:");
		for (int i = 0; i < 4; i++)
			System.out.println("Score for Student"+"[" + i + "]" + "= " +student_id[i]);
		
		//Multi dimension arrays
		
		int excelSheet[][] = new int [2][2];
		
		excelSheet[0][0] = 100;
		excelSheet[0][1] = 200;
		excelSheet[1][0] = 300;
		excelSheet[1][1] = 400;
		
		System.out.println("\nThe contents of excelSheet are as follows:");
		
		for(int row = 0; row < 2; row++)
		{
			for(int col = 0; col < 2; col++)
			{
				System.out.println("["+row+"]["+col+"] = " + excelSheet[row][col]);
				
			}
		}
		
		//String arrays
		
		String names[] = new String[5];
		
		names[0] = "Peter";
		names[1] = "Henry";
		names[2] = "John";
		names[3] = "Tammy";
		names[4] = "Cathy";
		
		int size = names.length;
		
		System.out.println("\nNames in the Array");
		
		for (int i = 0; i < size; i++)
		{
			System.out.println("names[" + i + "] = " + names[i]);
			
		}
		
		// Add more stuff for arraylist and lists etc.				
		
		
	}

}
