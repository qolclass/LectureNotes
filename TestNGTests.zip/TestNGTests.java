package pkg4_TestNGpkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNGTests
{
	public WebDriver driver;
	public String baseUrl;

	@BeforeMethod
	public void setUp()
	{
		System.setProperty("webdriver.gecko.driver",
				"C:\\Users\\root\\SupportingFiles\\WebDriver-jar-Files\\geckodriver-v0.17.0-win64\\geckodriver.exe");

		driver = new FirefoxDriver();
		baseUrl = "http://www.indeed.co.uk";
		System.out.println("\nThis is setUP()");

	}

	@Test(priority = 0)
	public void testIndeedJobSearch() throws InterruptedException
	{

		driver.get(baseUrl);
		String title = driver.getTitle();
		System.out.println("testIndeedJobSearcch(): Title ===> " + title);

		driver.findElement(By.id("what")).sendKeys("selenium");
		driver.findElement(By.id("where")).clear();
		driver.findElement(By.id("where")).sendKeys("London");
		driver.findElement(By.id("fj")).click();

		Thread.sleep(3000);

		String expectedTitle = "Selenium Jobs in London - January 2018 | Indeed.co.uk";
		String actualTitle = driver.getTitle();
		System.out.println("actualTitle    ==> " + actualTitle);
		System.out.println("expectedTitle  ==> " + expectedTitle);
		Assert.assertEquals(actualTitle, expectedTitle, "Error: Job search title is WRONG!!!");

	}

	@Test(priority = 1)
	public void testHomePageLogoDisplayed()
	{
		driver.get(baseUrl);
		System.out.println("\nThis is testHomePageLogoDisplayed()");
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='viewport']/div[2]/table/tbody/tr[1]/td/img")).isDisplayed(),
				"Error: logo is not displayed ");
	}

	@AfterMethod
	public void tearDown()
	{
		System.out.println("\nThis is tearDown()");
		driver.close();
		// driver.quit();
	}
}
