package pkg1_basicWebPageTesting;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class demoQAtesting {

	public static void main(String[] args) throws InterruptedException
	{
		WebDriver driver;

		System.setProperty("webdriver.gecko.driver", "D:\\Zrepo\\JDrivers\\gecko64-0.20.0\\geckodriver.exe");
		driver = new FirefoxDriver();

		driver.get("http://demo.automationtesting.in/Register.html");

		String Title = driver.getTitle();

		// Refresh
		System.out.println("Going for REFRESH button");
		driver.findElement(By.xpath(".//button[@id='Button1'][@type='button']")).click();

		System.out.println("Title = " + Title);

		// Firstname
		WebElement Fname = driver.findElement(By.xpath(".//input[@placeholder='First Name'][@type='text']"));
		Fname.sendKeys("MyFirstName");

		// Lastname
		WebElement Lname = driver.findElement(By.xpath(".//input[@placeholder='Last Name'][@type='text']"));
		Lname.sendKeys("MyLastName");

		// Address
		WebElement Address = driver.findElement(By.xpath(".//textarea[@rows='3'][@ng-model='Adress']"));
		Address.sendKeys("123 ABC Lane,\n" + "Some where in Some County,\n" + "Some City, Some State\n" + "Some Country. Ha Ha Ha");

		// email address
		WebElement email = driver.findElement(By.xpath(".//input[@ng-model='EmailAdress'][@type='email']"));
		email.sendKeys("somebody@nobody.com");

		// phone no
		WebElement phone = driver.findElement(By.xpath(".//input[@ng-model='Phone'][@type='tel']"));
		phone.sendKeys("1234567890");

		// radio button: Male
		driver.findElement(By.xpath(".//input[@type='radio'][@value='Male']")).click();
		Thread.sleep(2000);

		// radio button: FeMale
		driver.findElement(By.xpath(".//input[@type='radio'][@value='FeMale']")).click();

		// checkbox: Hockey
		driver.findElement(By.xpath(".//input[@id='checkbox3'][@value='Hockey']")).click();
		Thread.sleep(2000);

		// checkbox:Movies
		driver.findElement(By.xpath(".//input[@id='checkbox2'][@value='Movies']")).click();
		Thread.sleep(2000);

		// checkbox: Cricket
		driver.findElement(By.xpath(".//input[@id='checkbox1'][@value='Cricket']")).click();

		// Languages
		// locate the actual dropdown
		driver.findElement(By.xpath(".//div[@id='msdd']")).click();

		// implicit wait for the elements to appear
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Add more to complete the Language dropdown
		List<WebElement> Language = driver.findElements(By.xpath(".//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all']/li"));

		for (int i = 0; i < Language.size(); i++)
		{
			// String item = Language.get(i).getText();
			// {
			// if (item.contains("English"))
			// {
			// Language.get(i).click();
			// }
			// if (item.contains("Danish"))
			// {
			// Language.get(i).click();
			// }
			// }
			Language.get(i).click();
		}

		// Skills
		Select skills = new Select(driver.findElement(By.xpath(".//select[@ng-model='Skill'][@type='text']")));
		skills.selectByIndex(38);

		// Country
		Select country = new Select(driver.findElement(By.xpath(".//select[@ng-model='country'][@id='countries']")));
		country.selectByVisibleText("United States");

		// Select Country2
		Select country2 = new Select(driver.findElement(By.xpath(".//select[@id='country'][@class='select2-hidden-accessible']")));
		country2.selectByVisibleText("United States of America");

		// Year of Birth
		Select year = new Select(driver.findElement(By.xpath(".//select[@placeholder='Year'][@id='yearbox']")));
		year.selectByVisibleText("2015");

		// Month of Birth
		Select month = new Select(driver.findElement(By.xpath(".//select[@placeholder='Month'][@ng-model='monthbox']")));
		month.selectByVisibleText("November");

		// Day of Birth
		Select day = new Select(driver.findElement(By.xpath(".//select[@placeholder='Day'][@id='daybox']")));
		day.selectByIndex(6);

		// Password
		driver.findElement(By.xpath(".//input[@id='firstpassword'][@ng-model='Password']")).sendKeys("fakePassword");

		// Confirm Password
		driver.findElement(By.xpath(".//input[@id='secondpassword'][@ng-model='CPassword']")).sendKeys("fakePassword");

		// Submit
		System.out.println("Going for SUBMIT button");
		driver.findElement(By.xpath(".//button[@id='submitbtn'][@name='signup']")).click();

		// Choose File
		driver.findElement(By.xpath(".//input[@id='imagesrc'][@type='file']")).click();

	}

}
