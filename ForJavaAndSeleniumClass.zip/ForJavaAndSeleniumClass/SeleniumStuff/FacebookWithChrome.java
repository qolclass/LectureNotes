package pkg1_basicWebPageTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookWithChrome 
{

	public static void main(String[] args) 
	{
		String user= "xcsdds";
		String pass = "lkjlfkjdf";
		
		System.setProperty("webdriver.chrome.driver", "D:\\Zrepo\\JDrivers\\chrm-2.37\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		String titlePage = driver.getTitle();
		System.out.println("Title of the page ==> "+ titlePage);
		WebElement emailBox = driver.findElement(By.xpath("//input[@type='email']"));
		emailBox.sendKeys(user);
		
		driver.findElement(By.xpath("//input[@value='2']")).click();
		WebElement MaleRadioButton = driver.findElement(By.xpath("//input[@value='2']"));
		MaleRadioButton.click();
		System.out.println("Just Clicked the Male Radio Button");
	}
}
