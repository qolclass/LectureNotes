package pkg1_basicWebPageTesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class FacebookWithIE 
{
	public static void main(String[] args) throws InterruptedException
	{
		/*
		 * Issue with IE driver. Need to research and fix it
		 * Fixed by setting the zoom level to 100 in view
		 */
		System.setProperty("webdriver.ie.driver", "D:\\Zrepo\\JDrivers\\IE32-3.8.0\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver();
		driver.get("http://www.facebook.com");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		String titlePage = driver.getTitle();
		System.out.println("Title of the page ==> "+ titlePage);
		
	}
}
