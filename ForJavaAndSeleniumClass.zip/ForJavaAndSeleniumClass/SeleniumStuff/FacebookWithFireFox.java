package pkg1_basicWebPageTesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FacebookWithFireFox {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "D:\\Zrepo\\JDrivers\\gecko64-0.18.0\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.facebook.com");
		//driver.manage().window().maximize();
		String titlePage = driver.getTitle();
		System.out.println("Title of the page ==> "+ titlePage);

	}

}
