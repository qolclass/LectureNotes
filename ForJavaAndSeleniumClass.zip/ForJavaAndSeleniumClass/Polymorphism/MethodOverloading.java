package pkg_70_polymorphism;

public class MethodOverloading 
{
	/* This is static polymorphism (compile time binding) */
	/* signature ==> # of arguments
	 *   			 type of arguments
	 *   			 order of arguments
	 */
	

	public static void main(String[] args) 
	{
		MethodOverloading obj1 = new MethodOverloading();
		obj1.add(24.25, 16.75);
		obj1.add(24, 55);
		obj1.add(25.59, 25);

	}

	public void add(int a, int b)
	{
		int result = a+b;
		System.out.println("The Result of addition ==> "+ result);
		
	}
	
	public void add(int a, int b, int c)
	{
		int result = a+b+c;
		System.out.println("The Result of addition ==> "+ result);
		
	}
	
	public void add(int a, double b)
	{
		double result = a+b;
		System.out.println("The Result of addition ==> "+ result);
		
	}
	
	public void add(double a, double b)
	{
		double result = a+b;
		System.out.println("The Result of addition ==> "+ result);
		
	}
	
	public void add(double a, int b)
	{
		double result = a+b;
		System.out.println("The Result of addition ==> "+ result);
		
	}
	
	
}
