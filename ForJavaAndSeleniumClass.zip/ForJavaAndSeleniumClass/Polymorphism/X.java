package pkg_70_polymorphism;

public class X {
	// Constructor
	public X() {
		System.out.println("Constructor from Class X Called");
	}

	public void methodA() {
		System.out.println("Hello, I am methodA of class X");
	}
}
