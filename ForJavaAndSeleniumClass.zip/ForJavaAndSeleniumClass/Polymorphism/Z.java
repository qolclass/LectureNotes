package pkg_70_polymorphism;

/*
 * Explanation:
 * Look where the objects have been created. It seems reference of X is being created using Y.
 * Method for X's reference is expected to be called, but constructor call of Y for X reference 
 * creation, indirectly says the following:
 * Memory has been allocated to Y's object before X's reference is created.
 * 
 * As this occurs at runtime (not compile time) therefore compiler has no knowledge of which 
 * method will be called (from X or from Y). since this is a runtime event, JVM knows about it.
 */

public class Z {
	
	public static void main(String[] args) {

		X obj1 = new X(); // Reference and object of X

		X obj2 = new Y(); // Reference of X but object of Y

		obj1.methodA();
		obj2.methodA();
	}
}

