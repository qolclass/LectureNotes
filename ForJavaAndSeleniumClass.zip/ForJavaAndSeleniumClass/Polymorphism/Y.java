package pkg_70_polymorphism;

public class Y extends X {
	
	// Constructor
	public Y() {
		
		System.out.println("Y Constructor called");
	}

	public void methodA() {
		System.out.println("Hello, I am methodA of class Y");
	}
}
