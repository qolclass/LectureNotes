package pkg_50_ObjectOriented;

public class StaticAndNonStaticVer2 {

	String Name;
	String Addr;
	static String homeAddress = "1234 Somebodys Lane, Carrollton, TX 75010";
	
	StaticAndNonStaticVer2(String Name, String Addr)
	{
		this.Name = Name;
		this.Addr = Addr;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticAndNonStaticVer2 obj1 = new StaticAndNonStaticVer2("Mr. Karim","His Address");
		StaticAndNonStaticVer2 obj2 = new StaticAndNonStaticVer2("Mrs. Karim","Her Address");
		obj1.printit();
		obj2.printit();
		//System.out.println("Name = "+obj1.Name);
		//System.out.println("Addr = "+obj1.Addr);
		
		System.out.println("home Address = "+StaticAndNonStaticVer2.homeAddress);
		add(2,4);
	}
	
	public void printit()
	{
		System.out.println("First Name = "+Name);
		System.out.println("Address = "+Addr);
	}
	
	public static void add(int x, int y) {
		int z = x+y;
		System.out.println("add() --> x + y = "+z);
	}
}
