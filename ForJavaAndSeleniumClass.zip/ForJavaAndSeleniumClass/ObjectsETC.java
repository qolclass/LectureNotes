package pkg_50_ObjectOriented;

public class ObjectsETC
{
	String firstName; /* Instance variable */
	String lastName;  /* Instance variable */
	static String homeAddress = "1234 Somebodys Lane, Carrollton, TX 75010";
	static String country="USA";
	
	public String Greetings(String fName, String lName)
	{
		String fullName = fName +" " + lName;
		return "Hi There " +fullName;
	}
	
	public int sum(int value1, int value2)
	{
		return (value1+value2);
	}
	
	public int subtract(int value1, int value2)
	{
		return (value1-value2);
	}
	
	public static void main(String args[])
	{
		int x = 50; /* local variable */
		int y = 65; /* local variable */
		
		/* create object for the VariablesInJava Class */
		ObjectsETC obj1 = new ObjectsETC();
		ObjectsETC obj2 = new ObjectsETC();
		
		System.out.println("O1 - Home address -> " +ObjectsETC.homeAddress);
		ObjectsETC.homeAddress="I changed it buddy ha ha ha";
		System.out.println("Home address = " +ObjectsETC.homeAddress);
		System.out.println("O1 - Home address -> " +ObjectsETC.homeAddress);
		
		/* now obj1 can access the instance variable as follows */
		obj1.firstName = "James";
		obj1.lastName = "Bond";
		
		obj2.firstName = "Laloo";
		obj2.lastName = "Prasad";
		
		/* we can also call the object�s method as follows */
		String person = obj1.Greetings(obj1.firstName,obj1.lastName);
		System.out.println(person);
		
		String person2 = obj2.Greetings(obj2.firstName,obj2.lastName);
		System.out.println(person2);
		
		int addResult = obj1.sum(x,y);
		int subResult = obj1.subtract(x,y);
		System.out.println("Result of addition " +addResult);
		System.out.println("Result of subtraction " +subResult);
		
		int addResult2 = obj2.sum(x,y);
		System.out.println("O2 - Result of addition " +addResult2);
		System.out.println("O2 - Home address -> " +ObjectsETC.homeAddress);
		System.out.println(addResult2);
		
	}
}
