package pkg_50_ObjectOriented;

public class printClass2 
{
	String FullName = "James Bond";
	String Address = "Somewhere in the USA";
	
	public static void add()
	{
		System.out.println("This is the addtion Method from printClass2");
	}
	
	public static void sub()
	{
		System.out.println("This is the subtraction Method from printClass2");
	}
}
