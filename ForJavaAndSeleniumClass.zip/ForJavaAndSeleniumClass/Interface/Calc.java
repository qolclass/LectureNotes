package pkg_80_Interface;

public interface Calc 
{
	final int x = 100;
	
	void add();
	void sub();

}

