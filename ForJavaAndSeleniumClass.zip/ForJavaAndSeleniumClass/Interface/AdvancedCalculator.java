package pkg_80_Interface;

public class AdvancedCalculator implements Calc
{

	public static void main(String[] args) 
	{
		// case 1:Reference of Child class and object of Child class
		//        we can access the methods of the child class and the 
		//        methods of base class.

		
		AdvancedCalculator obj1 = new AdvancedCalculator();
		
		obj1.add();
		obj1.sub();
		obj1.genRandomNumbers();
		
		
		// case 2:Reference of Base Class, object of Child Class
		//        We can access only the methods of Base Class

		

		Calc obj2 = new AdvancedCalculator();
		obj2.add();
		obj2.sub();
		
		//obj2.genRandomNumbers(); //<-- cannot call (not visible)
	
	}

	public void genRandomNumbers()
	{
		System.out.println("This is genRandomNumbers method");
		
	}
	
	public void add() 
	{
		int y = 5;
		int z = x+y;
		
		System.out.println("This is the add() method " +z);
		
	}

	
	public void sub() 
	{
		System.out.println("This is the sub() method");
		
	}

}
