/* 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Key things to remember about interface:                                                       *
 *                                                                                               *
 * Interface is like a blueprint of a Class. It contains variables and                           *
 * body less methods(Abstract methods), where we just declare methods                            * 
 * but we implement them inside the class which inherits Interface.                              *
 *                                                                                               *
 * Note:- By default all the variables and methods inside an Interface are publicly accessible   *
 *                                                                                               *
 * Also:                                                                                         *
 * in the case of Interface: If we define a reference variable whose type is an interface,       *
 * any object we assign to it must be an instance of a Class that implements the interface.      *
 *                                                                                               *
 * In this example: MyWebDriver is an interface and the Class is MyFirefoxDriver. Therefore,     *
 * we can say the following:                                                                     *
 *                                                                                               *
 * * * * * * * * * * * * * * * MyWebDriver driver = new MyFirefoxDriver(); * * * * * * * * * * * *   
 *                                                                                               *
 * We can create a reference variable of an interface, but we can't instantiate any interface    *
 * since it is just a contract to be implemented in a Class.                                     *
 * Therefore: MyWebdriver driver = new MywebDriver()  <--- THIS IS NOT ALLOWED * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */

package pkg_80_Interface;

public interface MyWebDriver
{
	int x = 25;
	int y = 50;

	public String getCurrentURL();
	public void get(String url);
	public String getTitle();
	public void findElement();
	
}
