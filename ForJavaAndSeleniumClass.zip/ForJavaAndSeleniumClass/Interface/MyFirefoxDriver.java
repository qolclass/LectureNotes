package pkg_80_Interface;

import pkg_80_Interface.MyWebDriver;

public class MyFirefoxDriver implements MyWebDriver
{
	public MyFirefoxDriver() // Constructor
	{
		System.out.println("\nMyFirefoxDriver is being instantiated...\n");
	}
	
	public static void main(String[ ] args)
	{
		/*
		 * same as WebDriver driver = new FirefoxDriver();
		 * Note: Reference points to MyWebDriver but using object of the
		 * MyFirefoxDriver
		 */
		MyWebDriver driver = new MyFirefoxDriver();
		//MyWebDriver driver = new MyWebDriver(); <-- Not allowed
		/*
		 * Different then above :
		 * Here: Reference points to MyFirefoxDriver and using the object of
		 * MyFirefoxDriver
		 */
		MyFirefoxDriver mydriver = new MyFirefoxDriver();

		driver.get("http://www.nowhere.com");
		driver.findElement();
		String myURL = driver.getCurrentURL();
		String myTitle = driver.getTitle();

		System.out.println("Title = " + myTitle);
		System.out.println("URL = " + myURL);

		mydriver.add(2, 3);
		mydriver.get("JUNK");
		String x = mydriver.getTitle();
		System.out.println("Title ==> " + x);

	}
	
	/* Methods mandated by the MyWebDriver interface */
	public String getCurrentURL()
	{
		String x = "http://www.mywebsite.com";
		System.out.println("This is getCurrentURL() Method");
		return x;
	}

	public void get(String url)
	{
		System.out.println("This is the get method");
	}

	public String getTitle()
	{
		String x = "FaceBook login | login";
		return x;
	}

	public void findElement()
	{
		System.out.println("Found All elements, Ha Ha Ha");
	}
	
	/*
	 * Methods that are unique to MyFirefoxDriver Class
	 * [NOT Mandated by the interface]
	 */

	public void add(int a, int b)
	{
		System.out.println("This is the addition Method ==> NOT Mandated by the interface");
	}

	public void sub(int a, int b)
	{
		System.out.println("This is the subtraction Method ==> NOT Mandated by the interface");
	}

	public void mult(int a, int b)
	{
		System.out.println("This is the multiplication Method ==>> NOT Mandated by the interface");
	}

	public void div(int a, int b)
	{
		System.out.println("This is the division Method ==> NOT Mandated by the interface");
	}
}
