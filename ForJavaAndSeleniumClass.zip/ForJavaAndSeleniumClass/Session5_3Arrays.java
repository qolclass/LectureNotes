package pkg_1_Session5;

public class Session5_3Arrays {

	public static void main(String[] args) 
	{
		/*
		 * Syntax: datatype arrayname[] = new datatype[size];
		 */
		
		//Single dimension arrays
		int student_id[] = new int[4];
		
		student_id[0] = 50;
		student_id[1] = 60;
		student_id[2] = 70;
		student_id[3] = 80;
		//student_id[4] = 100;
		
		
		System.out.println("\nThe score for all students are as follows:");
		for (int i = 0; i < 4; i++)
			System.out.println("Score for Student"+"[" + i + "]" + "= " +student_id[i]);
		
		//Multi dimension arrays
		
		int excelSheet[][] = new int [2][2];
		
		excelSheet[0][0] = 100;
		excelSheet[0][1] = 200;
		excelSheet[1][0] = 300;
		excelSheet[1][1] = 400;
		
		System.out.println("\nThe contents of excelSheet are as follows:");
		
		for(int i = 0; i < 2; i++)
		{
			for(int j = 0; j < 2; j++)
			{
				System.out.println("["+i+"]["+j+"] = " + excelSheet[i][j]);
				
			}
		}
		
		//String arrays
		
		String names[] = new String[5];
		
		names[0] = "Iqbal";
		names[1] = "Murad";
		names[2] = "Afzal";
		names[3] = "Salim";
		names[4] = "Rahman";
		
		int size = names.length;
		
		System.out.println("\nNames in the Array");
		
		for (int i = 0; i < size; i++)
		{
			System.out.println("names[" + i + "] = " + names[i]);
			
		}
		
		// Add more stuff for arraylist and lists etc.				
		
		
	}

}
