package pkg_50_ObjectOriented;

public class EncapsulationConcept {

	public static void main(String[] args) {
		Student obj1 = new Student();
		obj1.setStudentName("Karim");
		String st_name = obj1.getStudentName();
		System.out.println(st_name);
		obj1.setStudentId(1234);
		int Id = obj1.getStudentId();
		System.out.println(Id);
	}
}


class Student {

	private String studentName;
	private int studentId;
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	
}


		