package pkg_50_ObjectOriented;

public class staticMethodExample 
{

	public static void main(String[] args) 
	{
		/* calling static methods directly without the use of 'new' */
		printClass2.add();
		printClass2.sub();

	}

}
