package pkg_50_ObjectOriented;

public class printClass 
{
	String FullName = "James Bond";
	String Address = "Somewhere in the USA";
	
	public void add()
	{
		System.out.println("This is the addtion Method from printClass");
	}
	
	public void sub()
	{
		System.out.println("This is the subtraction Method from printClass");
	}
}
