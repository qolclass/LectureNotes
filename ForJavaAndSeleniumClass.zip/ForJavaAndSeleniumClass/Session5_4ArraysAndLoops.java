package pkg_1_Session5;

import java.util.Arrays;

public class Session5_4ArraysAndLoops
{
	public static void main(String[ ] args)
	{
		/* Exercise with int arrays */
		int[ ] myArray = {56, 18, 33, 93, 14, 56, 35, 16, 3, 26, 67, 98, 49, 18, 53, 99, 56, 14, 12, 67, 88, 44, 4, 3, 56,
				24, 33, 0, 67, 93, 3, 4, 14, 35, 56, 18, 99, 15, 67, 93, 21, 35, 1, 2, 0, 16, 49, 49, 0, 33, 808};

		int length = myArray.length;

		/* Make a copy of myArray array */
		int[ ] mySortedArray = myArray.clone();

		/* List all elements of the Array */
		System.out.println("\nmyArray Length: " + length);
		System.out.println("\nmyArray[] Contents:\n");
		
		for(int i = 0; i<length; i++)
		{
			System.out.print(" " +myArray[i]);
		}
		System.out.println("\n");
		
		for (int i = 0; i < length; i++)
		{
			System.out.print("myArray[" + i + "]" + "= " + myArray[i] + "\t");
			if ((i > 0) && ((i + 1) % 5 == 0))
				System.out.println("\n");
		}

		/* Find the sum of all the numbers in the array */
		int sum = 0;
		for (int i = 0; i < length; i++)
		{
			sum = sum + myArray[i];
		}
		System.out.println("\n\nThe sum of all the numbers in the array --> " + sum);

		/* Find the Max number in the array */
		int max = 0;
		for (int i = 0; i < length; i++)
		{
			if (myArray[i] > max)
				max = myArray[i];
		}
		System.out.println("\nThe MAX number in the array --> " + max);
		
		
		/* Find the Min number in the array */
		int min = myArray[0];
		for (int i = 0; i < length; i++)
		{
			if (myArray[i] < min)
				min = myArray[i];
		}
		System.out.println("\nThe Min number in the array --> " + min + "\n\n");

		Arrays.sort(mySortedArray);

		System.out.println("Sorted array:\n");
		for (int i = 0; i < mySortedArray.length; i++)
			System.out.print(mySortedArray[i] + ",");
		System.out.println("\n");

		int count = 0;
		int startpos = 0;
		int dups;
		int[ ] index = new int[10];

		/* Find Multiple instances: print the index and the values */
		for (int i = 0; i < length; i++)
		{
			dups = 0;
			count = 0;
			int sample = mySortedArray[i];
			if ((i + 1) < length)
			{
				if (sample != mySortedArray[i + 1])
				{
					/* only one element */
					continue;
				}
				else
				{ /* it is atleast duplicate, check for more */
					startpos = i;
					count = 2;
					for (int k = i + 2; k < length; k++)
					{
						if (sample == mySortedArray[k])
							count = count + 1;
					}

					/* adjust i for sorted array access */
					i = startpos + (count - 1);
					/*
					 * coming out of the loop, we know the number of occurrences
					 * (count)
					 */
					/*
					 * we need to find each one of their indexes in myArray and
					 * print it
					 */
					for (int m = 0; m < length; m++)
					{
						/*
						 * find the indexes of each duplicate or more element in
						 * the myArray
						 */
						if (sample == myArray[m])
						{
							/* save the index */
							index[dups] = m;
							dups++;
						}
					}
					System.out.print("Multiple Instances of " + sample + " found at");
					for (int n = 0; n < count; n++)
					{
						System.out.print(" index " + index[n]);
					}
					System.out.println();
				}
			}
		}

		/*
		 * Exercise with String arrays
		 */
	}
}
