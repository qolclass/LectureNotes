package pkg_50_ObjectOriented;

public class StaticAndNonStatic {

	String Name;
	String Addr;
	static String homeAddress = "1234 Somebodys Lane, Carrollton, TX 75010";
	
	public static void main(String[] args) {
		
		
		
		//StaticAndNonStatic obj1 = new StaticAndNonStatic();
		//System.out.println("Name = "+obj1.Name);
		//System.out.println("Addr = "+obj1.Addr);
		
		System.out.println("home Address = "+StaticAndNonStatic.homeAddress);
		add(2,4);
	}
	
	public static void add(int x, int y) {
		int z = x+y;
		System.out.println("add() --> x + y = "+z);
	}

}
