package pkg_1_Session5;

public class Session5_2Arrays2
{
	public static void main(String[] args)
	{
		/*
		 * Exercise with int arrays
		 */

		/* List all members of the Array */

		int[] myArray = {56,108,33,93,14,35,16,3,26,67,98,49,108,53,125,14,102,67,88,44,4,3};
		int length = myArray.length;
		int dupArray[] = new int [length];
		
		//int [] dupArray = new int[length];
		boolean flag = false;
		
		/* List all members of the Array */
		System.out.println("myArray Length: " + length);
		System.out.println("myArray[] Contents:");
	
		for (int i = 0; i < length; i++)
		{	
			System.out.println("myArray[" + i + "]" + "= " + myArray[i]);
		}

		/* Find the sum of all the numbers in the array */
		int sum = 0;
		for (int i = 0; i < length; i++)
		{
			sum = sum + myArray[i];
		}
		System.out.println("\nThe sum of all the numbers in the array --> " + sum);
	
		/* Find the Max number in the array */
		int max = 0;
		for (int i = 0; i < length; i++)
		{
			if (myArray[i] > max)
				max = myArray[i];
		}
		System.out.println("\nThe MAX number in the array --> " + max);
	
		/* Find the Min number in the array */
		int min = myArray[0];
		for (int i = 0; i < length; i++)
		{
			if (myArray[i] < min)
				min = myArray[i];
		}
		System.out.println("\nThe Min number in the array --> " + min + "\n\n");
		
		int k = 0;
		/* Find duplicate values: print the index and the value */
		for(int i = 0; i < length; i++)
		{
			int sample = myArray[i];
			
			for (int j = 0; j < length; j++)
			{
				if(i == j)
					continue;

				if(sample == myArray[j])
				{
					/* check if the current # is already recorded */
					for(int d = 0; d < dupArray.length; d++)
					{
						if(sample == dupArray[d])
						{
							//System.out.println("Number already recorded: "+sample);
							flag = true;
						}
					}
					if(!flag)
					{
						/* put this number in dupArray */
						dupArray[k++] = sample;
						System.out.println("Duplicate Value: "+sample + " found at index = "+i + " and " +j);
					}
				}
			}
		}
		
		/*
		 * Exercise with String arrays
		 */

	}
}
