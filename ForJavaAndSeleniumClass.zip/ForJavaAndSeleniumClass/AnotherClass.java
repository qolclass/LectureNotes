package pkg_50_ObjectOriented;

public class AnotherClass 
{

	public static void main(String[] args) 
	{
		printClass obj1 = new printClass();
		
		obj1.add();
		
		obj1.sub();
		
		printClass2.add();
		printClass2.sub();
		System.out.println("First Name ==> " + obj1.FullName);
		
		System.out.println("Address ==> " + obj1.Address );
		
	}

}
 