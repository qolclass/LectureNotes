package pkg_1_Session5;

public class Session5_1Arrays1
{
	public static void main(String[] args)
	{
		/*
		 * Exercise with int arrays
		 */

		/* List all members of the Array */

		//int[] myArray = {56,108,33,93,14,35,16,3,26,67,98,49,108,53,125,14,102,67,88,44,4,3};
		int myArray[] = {56,108,33,93,14,35,16,3,26,67,98,49,108,53,125,14,102,67,88,44,4,3};
		
		System.out.println(" myarray[0] ==> "+myArray[0]);
		
		//int length =myArray.
		int length = myArray.length;
		
		//boolean flag = false;
			
		/* List all members of the Array */
		System.out.println("myArray Length: " + length);
		System.out.println("myArray[] Contents:");
		
		System.out.println("The contents and the SUM of the array are given below:");
		int sum = 0;
		
		for (int i = 0; i < length; i++)
		{
			sum = sum + myArray[i];
			System.out.println(myArray[i]);
			
		}
		for (int i = 0; i < myArray.length; i++)
		{
			System.out.println("myArray[" + i + "]" + "= " + myArray[i]);
		}
		
		System.out.println("SUM = " +sum);
	}

}
