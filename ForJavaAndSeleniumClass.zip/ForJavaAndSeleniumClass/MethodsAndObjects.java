package pkg_50_ObjectOriented;

public class MethodsAndObjects 
{
	int x = 5;
	int y = 10;
	
	public static void main(String[] args) 
	{
		System.out.println("Print something 1");
		
		MethodsAndObjects obj1 = new MethodsAndObjects();
		
		obj1.add();
		
		System.out.println("The value of x ==> " + obj1.x);
		System.out.println("The value of y ==> " + obj1.y);
		
		System.out.println("Print something 2");

	}
	
	
	
	public void add()
	{
		int x = 10;
		int y = 20;
		int z = x + y;
		
		System.out.println("The sum is " + z);
		
	}
	
	
	
}
