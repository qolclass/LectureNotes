package pkg_60_inheritance;

public class ClassA
{
	public String Avalue = "Base";

	public int add(int a, int b)
	{
		int c = a + b;
		return c;
	}

	public int sub(int x, int y)
	{
		int z = x - y;
		return z;
	}

	public String concat(String String1, String String2)
	{
		String String3 = String1 + String2;
		return String3;
	}
}

