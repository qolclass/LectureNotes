package pkg_60_inheritance;
/*
 * Note:
 * 1. Child class reference and Child class object:
 *    This will allow to access all the methods of base class
 *    and child class.
 *    Ex: ChildClass obj1 = new ChildClass();
 *    
 * 2. Base class reference and Base class object:
 *    This will allow to access all the methods of the base class only.
 *    
 * 3. Base class reference and Child class object:
 *    This will allow to access all the methods of the base class only
 *    and NOT child class method.
 *    
 * 4. Child class reference and Base class object:
 *    This is an invalid scenario: Child cannot hold parent !!!!
 */


public class ChildClass extends BaseClass
{

	public static void main(String[] args) 
	{
		ChildClass obj1 = new ChildClass();
		obj1.add();
		obj1.sub();
		obj1.mult();
		obj1.div();
	}

	public void mult()
	{
		System.out.println("This is ChildClass - mult ==> 30");
	}
	
	public void div()
	{
		System.out.println("This is ChildClass - div ==> 40");
	}
	
}

