package pkg_60_inheritance;

public class ClassC extends ClassB
{
	public String Greetings = "This is a demo of multi-level inheritance...";

	ClassC() // Constructor
	{
		System.out.println("\nThis is the Constructor from ClassC (C) talking...");
	}

	public void greet()
	{
		System.out.println("\nClassC (C) Child Class Printing: " + Greetings);
	}

	public static void main(String[] args)
	{
		ClassC obj = new ClassC();

		/* Current class printing this */
		obj.greet();

		/* calling methods() from the parent class (ClassB) */
		obj.whoami();

		double result1 = obj.mult(4.5, 2.5);
		System.out.println("\nThe result of multiplication (From ClassB (P)) = " + result1);

		double result2 = obj.div(15.0, 3.0);
		System.out.println("\nThe result of division (From ClassB (P)) = " + result2);

		/* call the methods from the GRAND parent (ClassA) class */
		int answer1 = obj.add(2, 3);
		System.out.println("\nThe answer of addition (From ClassA (GP)) ==>  " + answer1);

		int answer2 = obj.sub(3, 2);
		System.out.println("\nThe answer of subtraction (From ClassA (GP)) ==>  " + answer2);

		String fromGParent = obj.concat("HAWAII", " JAHAZ");
		System.out.println("\nThe concat result (From ClassA (GP)) ==>  " + fromGParent);

		System.out.println(
				"\nAnd Finally printing the private members From ClassB using getter and setter");

		obj.setAcctBalance(756000.00);
		obj.setAcctNmbr("XBP7556TTY5437");

		String AccountNumber = obj.getAcctNmbr();
		double AccountBalance = obj.getAcctBalance();

		System.out.println("\nAccount Number  ==> " + AccountNumber);
		System.out.println("\nAccount Balance ==> " + AccountBalance);
	}
}
