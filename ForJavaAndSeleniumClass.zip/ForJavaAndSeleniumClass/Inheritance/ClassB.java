package pkg_60_inheritance;

public class ClassB extends ClassA
{
	private String BValue = "Me - ClassB";
	private double AcctBalance;
	private String AcctNumber;

	public void whoami()
	{
		System.out.println("\nThis is " + BValue + " (P)");
	}

	public double mult(double firstNum, double secondNum)
	{
		double answer = firstNum * secondNum;
		return answer;
	}

	public double div(double first, double second)
	{
		return (first / second);
	}

	/* setter() */
	public void setAcctBalance(double newValue)
	{
		this.AcctBalance = newValue;
	}

	public void setAcctNmbr(String AcctNum)
	{
		this.AcctNumber = AcctNum;
	}

	/* getter() */
	public double getAcctBalance()
	{
		double bal = this.AcctBalance;
		return bal;
	}

	public String getAcctNmbr()
	{
		String actnbr = this.AcctNumber;
		return actnbr;
	}
}
