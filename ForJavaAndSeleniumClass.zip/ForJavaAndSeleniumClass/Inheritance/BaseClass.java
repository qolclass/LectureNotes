package pkg_60_inheritance;

public class BaseClass 
{
	public void add()
	{
		System.out.println("This is BaseClass - addition result ==> 10");
	}
	
	public void sub()
	{
		System.out.println("This is BaseClass - Subtraction result ==> 20");
	}
		
}
