package pkg_50_ObjectOriented;

public class StaticAndNonStaticDifference {

	public static void main(String[] args) {
		StaticAndNonStaticDifference.MethodStatic();
		//StaticAndNonStaticDifference nsm = new StaticAndNonStaticDifference();
		//nsm.MethodNonStatic();
		

	}

	public void MethodNonStatic() {
		System.out.println("Hello students, I am a NonStatic Method");
	}
	
	public static void MethodStatic() {
		System.out.println("Hello students, I am a Static Method");
	}
}
